angular.module('Questionnaire')
    .controller('MultipleChoiceAnswersInstanceEditController', [function() {

    }]);