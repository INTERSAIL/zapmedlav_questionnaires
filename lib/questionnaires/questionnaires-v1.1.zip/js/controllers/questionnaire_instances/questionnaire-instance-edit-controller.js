angular.module('Questionnaire')
    .controller('QuestionnaireInstanceEditController', ['$scope', '$routeParams', 'QuestionnaireInstanceHelper', function($scope, $routeParams, QuestionnaireInstanceHelper) {

    }]);