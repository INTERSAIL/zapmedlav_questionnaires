angular.module('Questionnaire')
    .controller('SingleChoiceAnswersInstanceEditController', [function() {

    }]);